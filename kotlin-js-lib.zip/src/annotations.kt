package js

public annotation class native(name: String? = null, qualifier: String? = null)
public annotation class enumerable
public annotation class optionsArg
